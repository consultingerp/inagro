To use this module, you need to:

* Create a new service order
* Under the Inventory tab, select the warehouse and add products with quantity
* Confirm the order to create the delivery orders
* Validate the transfers in the Inventory app. Quantities delivered on FSM
  Order Line will be updated.
