This module is an add-on for the Field Service application in Odoo.
It provides inventory and stock operations.
