* Go to Inventory
* Click on the Stock Requests tile to process stock requests
* You can also go to Inventory > Operations > Stock Requests
