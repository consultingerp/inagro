This module adds stock requests within the Inventory app with a new operation type.
